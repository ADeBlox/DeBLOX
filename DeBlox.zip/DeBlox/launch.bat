@echo off
set "url=%1"
set "pathpart=%url:deblox://=%"
for /f "tokens=1,2 delims=/" %%a in ("%pathpart%") do (
    set "mapid=%%a"
    set "username=%%b"
)

cd /d "C:\Users\saqht\OneDrive\Desktop\DeBlox"
DeBLOX.exe %mapid% %username%