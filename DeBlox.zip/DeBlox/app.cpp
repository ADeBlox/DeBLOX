#define NOGDI
#define NOUSER
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <wininet.h>

#undef NOGDI
#undef NOUSER

#include "raylib.h"
#include "rlgl.h"
#include <cmath>
#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <algorithm>
#include <sstream>

#pragma comment(lib, "wininet.lib")

inline Vector3 Vector3Add(Vector3 v1, Vector3 v2) {
    return (Vector3){ v1.x + v2.x, v1.y + v2.y, v1.z + v2.z };
}

inline Vector3 Vector3Scale(Vector3 v, float scale) {
    return (Vector3){ v.x * scale, v.y * scale, v.z * scale };
}

inline float Vector3Length(Vector3 v) {
    return sqrtf(v.x * v.x + v.y * v.y + v.z * v.z);
}

inline Vector3 Vector3Normalize(Vector3 v) {
    float length = Vector3Length(v);
    if (length == 0.0f) length = 1.0f;
    float ilength = 1.0f / length;
    return (Vector3){ v.x * ilength, v.y * ilength, v.z * ilength };
}

inline Vector3 Vector3Lerp(Vector3 v1, Vector3 v2, float amount) {
    return (Vector3){
        v1.x + amount * (v2.x - v1.x),
        v1.y + amount * (v2.y - v1.y),
        v1.z + amount * (v2.z - v1.z)
    };
}

const std::string SUPABASE_URL = "fyaenayirqkyqmsvqwvu.supabase.co";
const std::string API_KEY = "sb_publishable_6TPxZAyr9udsr6WyiOohlQ_PIferL2Z";

int currentMapId = 1;

struct ChatBubble {
    std::string username;
    std::string text;
    Vector3 worldPosition;
    float timer;
    bool active;
    bool sentToServerDeletion = false;
};

struct WorldPart {
    Vector3 position;
    Vector3 size;
    Color color;
};

struct RemotePlayer {
    std::string username;
    Vector3 position;
    Vector3 targetPosition;
    float rotation;
    float targetRotation;
    float inactiveTimer;
};

std::vector<RemotePlayer> remotePlayers;
std::vector<ChatBubble> chatBubbles;
std::mutex dataMutex;
std::string localUsername = "Player1";
bool networkingActive = true;
double clientStartTime = 0.0;

void FetchMapBlocks(int mapId, std::vector<WorldPart>& parts) {
    std::string host = SUPABASE_URL;
    if (host.rfind("https://", 0) == 0) host = host.substr(8);
    if (host.back() == '/') host.pop_back();

    HINTERNET hSession = InternetOpenA("DeBloxClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hSession) return;

    HINTERNET hConnect = InternetConnectA(hSession, host.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (hConnect) {
        std::string path = "/rest/v1/map_blocks?map_id=eq." + std::to_string(mapId) + "&select=x,y,z,size_x,size_y,size_z,r,g,b";
        HINTERNET hRequest = HttpOpenRequestA(hConnect, "GET", path.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
        if (hRequest) {
            std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\nCache-Control: no-cache\r\n";
            HttpSendRequestA(hRequest, headers.c_str(), headers.length(), NULL, 0);

            char buffer[4096];
            DWORD bytesRead = 0;
            std::string response = "";
            while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                buffer[bytesRead] = '\0';
                response += buffer;
            }
            InternetCloseHandle(hRequest);

            size_t pos = 0;
            while ((pos = response.find("\"x\":", pos)) != std::string::npos) {
                size_t startObj = response.rfind("{", pos);
                size_t endObj = response.find("}", pos);
                if (startObj == std::string::npos || endObj == std::string::npos) break;

                std::string obj = response.substr(startObj, endObj - startObj + 1);
                WorldPart part;
                part.position = {0, 0, 0};
                part.size = {4.0f, 4.0f, 4.0f};
                part.color = { 240, 240, 240, 255 }; // لون افتراضي فاتح لضمان عدم اختفاء البلوكات

                size_t xKey = obj.find("\"x\":"); if (xKey != std::string::npos) part.position.x = std::stof(obj.substr(xKey + 4));
                size_t yKey = obj.find("\"y\":"); if (yKey != std::string::npos) part.position.y = std::stof(obj.substr(yKey + 4));
                size_t zKey = obj.find("\"z\":"); if (zKey != std::string::npos) part.position.z = std::stof(obj.substr(zKey + 4));
                
                size_t sxKey = obj.find("\"size_x\":"); if (sxKey != std::string::npos) part.size.x = std::stof(obj.substr(sxKey + 9));
                size_t syKey = obj.find("\"size_y\":"); if (syKey != std::string::npos) part.size.y = std::stof(obj.substr(syKey + 9));
                size_t szKey = obj.find("\"size_z\":"); if (szKey != std::string::npos) part.size.z = std::stof(obj.substr(szKey + 9));

                auto parseColorVal = [&](const std::string& key, unsigned char& colVal) {
                    size_t keyPos = obj.find(key);
                    if (keyPos != std::string::npos) {
                        size_t colonPos = obj.find(":", keyPos);
                        if (colonPos != std::string::npos) {
                            colVal = (unsigned char)std::stoi(obj.substr(colonPos + 1));
                        }
                    }
                };

                parseColorVal("\"r\":", part.color.r);
                parseColorVal("\"g\":", part.color.g);
                parseColorVal("\"b\":", part.color.b);
                parseColorVal("\"red\":", part.color.r);
                parseColorVal("\"green\":", part.color.g);
                parseColorVal("\"blue\":", part.color.b);
                part.color.a = 255;

                parts.push_back(part);
                pos = endObj + 1;
            }
        }
        InternetCloseHandle(hConnect);
    }
    InternetCloseHandle(hSession);
}

void DeleteChatMessageFromSupabase(const std::string& username, const std::string& message) {
    HINTERNET hSession = InternetOpenA("DeBloxClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (hSession) {
        HINTERNET hConnect = InternetConnectA(hSession, SUPABASE_URL.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (hConnect) {
            std::string path = "/rest/v1/chat_messages?map_id=eq." + std::to_string(currentMapId) + "&username=eq." + username + "&message=eq." + message;
            HINTERNET hRequest = HttpOpenRequestA(hConnect, "DELETE", path.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);
            if (hRequest) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\n";
                HttpSendRequestA(hRequest, headers.c_str(), headers.length(), NULL, 0);
                InternetCloseHandle(hRequest);
            }
            InternetCloseHandle(hConnect);
        }
        InternetCloseHandle(hSession);
    }
}

std::string GetNextAvailableUsername() {
    std::vector<std::string> existingNames;
    HINTERNET hSession = InternetOpenA("DeBloxClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (hSession) {
        HINTERNET hConnect = InternetConnectA(hSession, SUPABASE_URL.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (hConnect) {
            std::string path = "/rest/v1/players?map_id=eq." + std::to_string(currentMapId) + "&select=username";
            HINTERNET hGetRequest = HttpOpenRequestA(hConnect, "GET", path.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);
            if (hGetRequest) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\n";
                HttpSendRequestA(hGetRequest, headers.c_str(), headers.length(), NULL, 0);

                char buffer[4096];
                DWORD bytesRead = 0;
                std::string response = "";
                while (InternetReadFile(hGetRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    response += buffer;
                }
                InternetCloseHandle(hGetRequest);

                size_t pos = 0;
                while ((pos = response.find("\"username\":", pos)) != std::string::npos) {
                    size_t startU = response.find("\"", pos + 11);
                    if (startU != std::string::npos) {
                        startU++;
                        size_t endU = response.find("\"", startU);
                        if (endU != std::string::npos) {
                            existingNames.push_back(response.substr(startU, endU - startU));
                        }
                        pos = endU + 1;
                    } else {
                        pos += 11;
                    }
                }
            }
            InternetCloseHandle(hConnect);
        }
        InternetCloseHandle(hSession);
    }

    for (int i = 1; i <= 100; i++) {
        std::string candidate = "Player" + std::to_string(i);
        bool taken = false;
        for (const auto& name : existingNames) {
            if (name == candidate) {
                taken = true;
                break;
            }
        }
        if (!taken) {
            return candidate;
        }
    }
    return "Player100";
}

void RemovePlayerFromSupabase(const std::string& username) {
    HINTERNET hSession = InternetOpenA("DeBloxClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (hSession) {
        HINTERNET hConnect = InternetConnectA(hSession, SUPABASE_URL.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (hConnect) {
            std::string path = "/rest/v1/players?map_id=eq." + std::to_string(currentMapId) + "&username=eq." + username;
            HINTERNET hRequest = HttpOpenRequestA(hConnect, "DELETE", path.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);
            if (hRequest) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\n";
                HttpSendRequestA(hRequest, headers.c_str(), headers.length(), NULL, 0);
                InternetCloseHandle(hRequest);
            }
            InternetCloseHandle(hConnect);
        }
        InternetCloseHandle(hSession);
    }
}

void NetworkSyncLoop(Vector3* pPos, float* pRot, bool* active) {
    HINTERNET hSession = InternetOpenA("DeBloxClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hSession) return;

    while (*active) {
        Vector3 currentPos = *pPos;
        float currentRot = *pRot;

        HINTERNET hConnect = InternetConnectA(hSession, SUPABASE_URL.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (hConnect) {
            HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", "/rest/v1/players?on_conflict=username", NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);
            if (hRequest) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\nContent-Type: application/json\r\nPrefer: resolution=merge-duplicates\r\n";
                
                std::ostringstream ss;
                ss.imbue(std::locale::classic());
                ss << "{\"username\":\"" << localUsername << "\",\"map_id\":" << currentMapId << ",\"x\":" << currentPos.x << ",\"y\":" << currentPos.y << ",\"z\":" << currentPos.z << ",\"rotation\":" << currentRot << "}";
                std::string jsonBody = ss.str();
                
                HttpSendRequestA(hRequest, headers.c_str(), headers.length(), (LPVOID)jsonBody.c_str(), jsonBody.length());
                InternetCloseHandle(hRequest);
            }

            std::string getPlayersPath = "/rest/v1/players?map_id=eq." + std::to_string(currentMapId) + "&select=username,x,y,z,rotation";
            HINTERNET hGetRequest = HttpOpenRequestA(hConnect, "GET", getPlayersPath.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
            if (hGetRequest) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\nCache-Control: no-cache\r\nPragma: no-cache\r\n";
                HttpSendRequestA(hGetRequest, headers.c_str(), headers.length(), NULL, 0);

                char buffer[4096];
                DWORD bytesRead = 0;
                std::string response = "";
                while (InternetReadFile(hGetRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                    buffer[bytesRead] = '\0';
                    response += buffer;
                }
                InternetCloseHandle(hGetRequest);

                if (!response.empty() && response.find("username") != std::string::npos) {
                    std::vector<RemotePlayer> tempPlayers;
                    size_t pos = 0;
                    while ((pos = response.find("\"username\":", pos)) != std::string::npos) {
                        size_t startObj = response.rfind("{", pos);
                        size_t endObj = response.find("}", pos);
                        if (startObj == std::string::npos || endObj == std::string::npos) break;
                        
                        std::string obj = response.substr(startObj, endObj - startObj + 1);

                        std::string uName = "";
                        size_t uKey = obj.find("\"username\":\"");
                        if (uKey != std::string::npos) {
                            size_t startU = uKey + 12;
                            size_t endU = obj.find("\"", startU);
                            if (endU != std::string::npos) uName = obj.substr(startU, endU - startU);
                        }

                        if (!uName.empty() && uName != localUsername) {
                            RemotePlayer rp;
                            rp.username = uName;
                            rp.targetPosition = {0,0,0};
                            rp.targetRotation = 0;
                            rp.inactiveTimer = 0.0f;

                            size_t xKey = obj.find("\"x\":");
                            if (xKey != std::string::npos) rp.targetPosition.x = std::stof(obj.substr(xKey + 4));
                            size_t yKey = obj.find("\"y\":");
                            if (yKey != std::string::npos) rp.targetPosition.y = std::stof(obj.substr(yKey + 4));
                            size_t zKey = obj.find("\"z\":");
                            if (zKey != std::string::npos) rp.targetPosition.z = std::stof(obj.substr(zKey + 4));
                            size_t rKey = obj.find("\"rotation\":");
                            if (rKey != std::string::npos) rp.targetRotation = std::stof(obj.substr(rKey + 11));

                            rp.position = rp.targetPosition;
                            rp.rotation = rp.targetRotation;

                            tempPlayers.push_back(rp);
                        }
                        pos = endObj + 1;
                    }

                    if (!tempPlayers.empty()) {
                        std::lock_guard<std::mutex> lock(dataMutex);
                        for (auto& newP : tempPlayers) {
                            bool found = false;
                            for (auto& oldP : remotePlayers) {
                                if (oldP.username == newP.username) {
                                    oldP.targetPosition = newP.targetPosition;
                                    oldP.targetRotation = newP.targetRotation;
                                    oldP.inactiveTimer = 0.0f;
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                remotePlayers.push_back(newP);
                            }
                        }

                        for (auto it = remotePlayers.begin(); it != remotePlayers.end(); ) {
                            bool exists = false;
                            for (const auto& newP : tempPlayers) {
                                if (newP.username == it->username) {
                                    exists = true;
                                    break;
                                }
                            }
                            if (!exists) {
                                it = remotePlayers.erase(it);
                            } else {
                                ++it;
                            }
                        }
                    }
                }
            }

            std::string getChatPath = "/rest/v1/chat_messages?map_id=eq." + std::to_string(currentMapId) + "&select=username,message&order=id.desc&limit=5";
            HINTERNET hChatGet = HttpOpenRequestA(hConnect, "GET", getChatPath.c_str(), NULL, NULL, NULL, INTERNET_FLAG_SECURE | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
            if (hChatGet) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\nCache-Control: no-cache\r\nPragma: no-cache\r\n";
                HttpSendRequestA(hChatGet, headers.c_str(), headers.length(), NULL, 0);

                char chatBuffer[4096];
                DWORD chatBytes = 0;
                std::string chatResponse = "";
                while (InternetReadFile(hChatGet, chatBuffer, sizeof(chatBuffer) - 1, &chatBytes) && chatBytes > 0) {
                    chatBuffer[chatBytes] = '\0';
                    chatResponse += chatBuffer;
                }
                InternetCloseHandle(hChatGet);

                size_t cPos = 0;
                while ((cPos = chatResponse.find("\"username\":", cPos)) != std::string::npos) {
                    size_t cStartObj = chatResponse.rfind("{", cPos);
                    size_t cEndObj = chatResponse.find("}", cPos);
                    if (cStartObj == std::string::npos || cEndObj == std::string::npos) break;

                    std::string cObj = chatResponse.substr(cStartObj, cEndObj - cStartObj + 1);
                    std::string cUser = "";
                    std::string cText = "";

                    size_t uKey = cObj.find("\"username\":\"");
                    if (uKey != std::string::npos) {
                        size_t sU = uKey + 12;
                        size_t eU = cObj.find("\"", sU);
                        if (eU != std::string::npos) cUser = cObj.substr(sU, eU - sU);
                    }

                    size_t mKey = cObj.find("\"message\":\"");
                    if (mKey != std::string::npos) {
                        size_t sM = mKey + 11;
                        size_t eM = cObj.find("\"", sM);
                        if (eM != std::string::npos) cText = cObj.substr(sM, eM - sM);
                    }

                    if (!cUser.empty() && !cText.empty()) {
                        std::lock_guard<std::mutex> lock(dataMutex);
                        bool msgExists = false;
                        for (const auto& b : chatBubbles) {
                            if (b.username == cUser && b.text == cText) {
                                msgExists = true;
                                break;
                            }
                        }
                        if (!msgExists && GetTime() > clientStartTime + 2.0) {
                            ChatBubble nb;
                            nb.username = cUser;
                            nb.text = cText;
                            nb.timer = 8.0f;
                            nb.active = true;
                            nb.sentToServerDeletion = false;
                            chatBubbles.push_back(nb);
                        }
                    }
                    cPos = cEndObj + 1;
                }
            }

            InternetCloseHandle(hConnect);
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    InternetCloseHandle(hSession);
}

void SendChat(const std::string& username, const std::string& message) {
    HINTERNET hSession = InternetOpenA("DeBloxClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (hSession) {
        HINTERNET hConnect = InternetConnectA(hSession, SUPABASE_URL.c_str(), INTERNET_DEFAULT_HTTPS_PORT, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
        if (hConnect) {
            HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", "/rest/v1/chat_messages", NULL, NULL, NULL, INTERNET_FLAG_SECURE, 0);
            if (hRequest) {
                std::string headers = "apikey: " + API_KEY + "\r\nAuthorization: Bearer " + API_KEY + "\r\nContent-Type: application/json\r\nPrefer: return=minimal\r\n";
                std::string jsonBody = "{\"username\":\"" + username + "\",\"map_id\":" + std::to_string(currentMapId) + ",\"message\":\"" + message + "\"}";

                HttpSendRequestA(hRequest, headers.c_str(), headers.length(), (LPVOID)jsonBody.c_str(), jsonBody.length());
                InternetCloseHandle(hRequest);
            }
            InternetCloseHandle(hConnect);
        }
        InternetCloseHandle(hSession);
    }
}

void UpdateAndDrawBubbles(Camera3D camera, float deltaTime, Vector3 localPos, const std::vector<RemotePlayer>& players) {
    std::lock_guard<std::mutex> lock(dataMutex);
    for (size_t i = 0; i < chatBubbles.size(); i++) {
        if (!chatBubbles[i].active) {
            if (!chatBubbles[i].sentToServerDeletion) {
                chatBubbles[i].sentToServerDeletion = true;
                std::thread(DeleteChatMessageFromSupabase, chatBubbles[i].username, chatBubbles[i].text).detach();
            }
            continue;
        }

        chatBubbles[i].timer -= deltaTime;
        if (chatBubbles[i].timer <= 0.0f) {
            chatBubbles[i].active = false;
            continue;
        }

        Vector3 targetPos = localPos;
        if (chatBubbles[i].username != localUsername) {
            for (const auto& p : players) {
                if (p.username == chatBubbles[i].username) {
                    targetPos = p.position;
                    break;
                }
            }
        }

        chatBubbles[i].worldPosition = (Vector3){ targetPos.x, targetPos.y + 6.5f, targetPos.z };
        Vector2 screenPos = GetWorldToScreen(chatBubbles[i].worldPosition, camera);

        if (screenPos.x > 0 && screenPos.y > 0) {
            std::string fullText = chatBubbles[i].username + ": " + chatBubbles[i].text;
            int fontSize = 18;
            int textWidth = MeasureText(fullText.c_str(), fontSize);
            int padding = 10;
            
            Rectangle bubbleRect = {
                screenPos.x - (textWidth / 2.0f) - padding,
                screenPos.y - (fontSize / 2.0f) - padding,
                (float)(textWidth + (padding * 2)),
                (float)(fontSize + (padding * 2))
            };

            DrawRectangleRounded(bubbleRect, 0.4f, 4, WHITE);
            DrawRectangleRoundedLines(bubbleRect, 0.4f, 4, LIGHTGRAY);
            DrawText(fullText.c_str(), (int)(screenPos.x - (textWidth / 2.0f)), (int)(screenPos.y - (fontSize / 2.0f)), fontSize, DARKGRAY);
        }
    }
}

void DrawR6Character(Vector3 pos, float yawAngle, Texture2D faceTex, const std::string& name = "") {
    Color skinColor  = (Color){ 245, 205, 47, 255 };
    Color torsoColor = (Color){ 13, 105, 172, 255 };
    Color legsColor  = (Color){ 164, 189, 71, 255 };

    rlPushMatrix();
        rlTranslatef(pos.x, pos.y, pos.z);
        rlRotatef(yawAngle, 0.0f, 1.0f, 0.0f);

        DrawCube((Vector3){ -0.5f, 1.0f, 0.0f }, 1.0f, 2.0f, 1.0f, legsColor);
        DrawCubeWires((Vector3){ -0.5f, 1.0f, 0.0f }, 1.0f, 2.0f, 1.0f, BLACK);

        DrawCube((Vector3){  0.5f, 1.0f, 0.0f }, 1.0f, 2.0f, 1.0f, legsColor);
        DrawCubeWires((Vector3){  0.5f, 1.0f, 0.0f }, 1.0f, 2.0f, 1.0f, BLACK);

        DrawCube((Vector3){ 0.0f, 3.0f, 0.0f }, 2.0f, 2.0f, 1.0f, torsoColor);
        DrawCubeWires((Vector3){ 0.0f, 3.0f, 0.0f }, 2.0f, 2.0f, 1.0f, BLACK);

        DrawCube((Vector3){ -1.5f, 3.0f, 0.0f }, 1.0f, 2.0f, 1.0f, skinColor);
        DrawCubeWires((Vector3){ -1.5f, 3.0f, 0.0f }, 1.0f, 2.0f, 1.0f, skinColor);

        DrawCube((Vector3){  1.5f, 3.0f, 0.0f }, 1.0f, 2.0f, 1.0f, skinColor);
        DrawCubeWires((Vector3){  1.5f, 3.0f, 0.0f }, 1.0f, 2.0f, 1.0f, skinColor);

        Vector3 headPos = { 0.0f, 4.625f, 0.0f };
        DrawCube(headPos, 1.25f, 1.25f, 1.25f, skinColor);
        DrawCubeWires(headPos, 1.25f, 1.25f, 1.25f, BLACK);

        if (faceTex.id > 0) {
            rlSetTexture(faceTex.id);
            rlBegin(RL_QUADS);
                rlColor4ub(255, 255, 255, 255);
                rlTexCoord2f(0.0f, 0.0f); rlVertex3f(-0.625f, 5.25f, -0.626f);
                rlTexCoord2f(0.0f, 1.0f); rlVertex3f(-0.625f, 4.0f,  -0.626f);
                rlTexCoord2f(1.0f, 1.0f); rlVertex3f( 0.625f, 4.0f,  -0.626f);
                rlTexCoord2f(1.0f, 0.0f); rlVertex3f( 0.625f, 5.25f, -0.626f);
            rlEnd();
            rlSetTexture(0);
        }

    rlPopMatrix();
}

int main(int argc, char* argv[]) {
    if (argc > 1) {
        currentMapId = std::stoi(argv[1]);
    }
    if (argc > 2) {
        localUsername = argv[2];
    } else {
        localUsername = GetNextAvailableUsername();
    }

    SetConfigFlags(FLAG_WINDOW_RESIZABLE | FLAG_MSAA_4X_HINT);
    InitWindow(1280, 720, ("DeBlox Engine - Map " + std::to_string(currentMapId) + " - " + localUsername).c_str());
    SetTargetFPS(60);

    clientStartTime = GetTime();

    Texture2D cursorFarTex   = LoadTexture("content/textures/ArrowFarCursor.png");
    Texture2D cursorArrowTex = LoadTexture("content/textures/ArrowCursor.png");
    Texture2D cursorIBeamTex = LoadTexture("content/textures/IBeamCursor.png");
    
    Texture2D topStudTex     = LoadTexture("content/textures/stud.png");
    if (topStudTex.id == 0) {
        topStudTex           = LoadTexture("content/textures/plastic.png");
    }
    Texture2D bottomSmsTex   = LoadTexture("content/textures/shell/sms.png");
    Texture2D faceTex        = LoadTexture("content/textures/face.png");
    Texture2D menuBtnTex     = LoadTexture("ExtraContent/ui/menu_button_icon.png");
    Texture2D chatBtnTex     = LoadTexture("ExtraContent/ui/chat_button_icon.png");

    if (topStudTex.id > 0) {
        GenTextureMipmaps(&topStudTex);
        SetTextureFilter(topStudTex, TEXTURE_FILTER_TRILINEAR);
        SetTextureWrap(topStudTex, TEXTURE_WRAP_REPEAT);
    }
    if (bottomSmsTex.id > 0) {
        GenTextureMipmaps(&bottomSmsTex);
        SetTextureFilter(bottomSmsTex, TEXTURE_FILTER_TRILINEAR);
        SetTextureWrap(bottomSmsTex, TEXTURE_WRAP_REPEAT);
    }
    if (faceTex.id > 0) SetTextureFilter(faceTex, TEXTURE_FILTER_POINT);

    HideCursor();

    Camera3D camera = { 0 };
    float cameraDistance = 12.5f; 
    float cameraAngleYaw = 0.0f;
    float cameraAnglePitch = 20.0f;

    camera.up = (Vector3){ 0.0f, 1.0f, 0.0f };
    camera.fovy = 70.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    Vector3 playerPos = { 0.0f, 0.0f, 0.0f };
    float playerRotation = 0.0f;
    
    float walkSpeed = 16.0f; 
    const float ROBLOX_GRAVITY = -196.2f; 
    const float JUMP_POWER = 50.0f;
    
    float verticalVelocity = 0.0f;
    bool isGrounded = false;

    std::thread netThread(NetworkSyncLoop, &playerPos, &playerRotation, &networkingActive);

    std::vector<WorldPart> worldParts;
    FetchMapBlocks(currentMapId, worldParts);

    char chatInput[128] = "\0";
    int letterCount = 0;
    bool isChatActive = false;
    bool isMenuOpen = false;

    Rectangle menuBtnRect = { 10, 10, 40, 40 };
    Rectangle chatBtnRect = { 55, 10, 40, 40 };
    Rectangle chatBarRect = { 10, 60, 350, 35 };

    while (!WindowShouldClose()) {
        float deltaTime = GetFrameTime();
        if (deltaTime > 0.1f) deltaTime = 0.1f;
        Vector2 mousePos = GetMousePosition();
	
        if (IsKeyPressed(KEY_F11)) {
            ToggleFullscreen();
        }

        int screenWidth = GetScreenWidth();
        int screenHeight = GetScreenHeight();

        Rectangle menuOverlayRect = { (float)screenWidth / 2.0f - 150.0f, (float)screenHeight / 2.0f - 100.0f, 300.0f, 200.0f };
        Rectangle resetBtnRect    = { menuOverlayRect.x + 30.0f, menuOverlayRect.y + 50.0f, 240.0f, 40.0f };
        Rectangle leaveBtnRect    = { menuOverlayRect.x + 30.0f, menuOverlayRect.y + 110.0f, 240.0f, 40.0f };

        if ((CheckCollisionPointRec(mousePos, menuBtnRect) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) || IsKeyPressed(KEY_ESCAPE)) {
            if (!isChatActive) {
                isMenuOpen = !isMenuOpen;
            } else {
                isChatActive = false;
            }
        }

        if (CheckCollisionPointRec(mousePos, chatBtnRect) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            isChatActive = !isChatActive;
            if (isChatActive) isMenuOpen = false;
        }

        if (isMenuOpen) {
            if (CheckCollisionPointRec(mousePos, resetBtnRect) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                playerPos = (Vector3){ 0.0f, 0.0f, 0.0f };
                verticalVelocity = 0.0f;
                isMenuOpen = false;
            }
            if (CheckCollisionPointRec(mousePos, leaveBtnRect) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                break;
            }
        }

        if (!isMenuOpen) {
            if (IsMouseButtonDown(MOUSE_BUTTON_RIGHT)) {
                Vector2 delta = GetMouseDelta();
                cameraAngleYaw -= delta.x * 0.3f;
                cameraAnglePitch += delta.y * 0.3f;

                if (cameraAnglePitch > 85.0f) cameraAnglePitch = 85.0f;
                if (cameraAnglePitch < -10.0f) cameraAnglePitch = -10.0f;
            }

            float wheel = GetMouseWheelMove();
            if (wheel != 0) {
                cameraDistance -= wheel * 2.0f;
                if (cameraDistance < 4.0f) cameraDistance = 4.0f;
                if (cameraDistance > 100.0f) cameraDistance = 100.0f;
            }

            if (IsKeyPressed(KEY_SLASH) && !isChatActive) {
                isChatActive = true;
            }

            if (CheckCollisionPointRec(mousePos, chatBarRect) && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
                isChatActive = true;
            }

            if (isChatActive) {
                int key = GetCharPressed();
                while (key > 0) {
                    if ((key >= 32) && (key <= 125) && (letterCount < 127)) {
                        chatInput[letterCount] = (char)key;
                        chatInput[letterCount + 1] = '\0';
                        letterCount++;
                    }
                    key = GetCharPressed();
                }

                if (IsKeyPressed(KEY_BACKSPACE)) {
                    letterCount--;
                    if (letterCount < 0) letterCount = 0;
                    chatInput[letterCount] = '\0';
                }

                if (IsKeyPressed(KEY_ENTER) && letterCount > 0) {
                    std::string msg = chatInput;
                    {
                        std::lock_guard<std::mutex> lock(dataMutex);
                        ChatBubble localB;
                        localB.username = localUsername;
                        localB.text = msg;
                        localB.timer = 8.0f;
                        localB.active = true;
                        localB.sentToServerDeletion = false;
                        chatBubbles.push_back(localB);
                    }
                    SendChat(localUsername, msg);
                    chatInput[0] = '\0';
                    letterCount = 0;
                    isChatActive = false;
                }
            } else {
                float radYaw = cameraAngleYaw * DEG2RAD;
                Vector3 forward = { sinf(radYaw), 0.0f, cosf(radYaw) };
                Vector3 right = { cosf(radYaw), 0.0f, -sinf(radYaw) };

                Vector3 moveDir = { 0.0f, 0.0f, 0.0f };

                if (IsKeyDown(KEY_W) || IsKeyDown(KEY_UP)) moveDir = Vector3Add(moveDir, Vector3Scale(forward, -1.0f));
                if (IsKeyDown(KEY_S) || IsKeyDown(KEY_DOWN)) moveDir = Vector3Add(moveDir, forward);
                if (IsKeyDown(KEY_A) || IsKeyDown(KEY_LEFT)) moveDir = Vector3Add(moveDir, Vector3Scale(right, -1.0f));
                if (IsKeyDown(KEY_D) || IsKeyDown(KEY_RIGHT)) moveDir = Vector3Add(moveDir, right);

                if (Vector3Length(moveDir) > 0.0f) {
                    moveDir = Vector3Normalize(moveDir);
                    playerPos.x += moveDir.x * walkSpeed * deltaTime;
                    playerPos.z += moveDir.z * walkSpeed * deltaTime;
                    playerRotation = RAD2DEG * atan2f(-moveDir.x, -moveDir.z);
                }

                if (IsKeyPressed(KEY_SPACE) && isGrounded) {
                    verticalVelocity = JUMP_POWER;
                    isGrounded = false;
                }
            }

            verticalVelocity += ROBLOX_GRAVITY * deltaTime;
            playerPos.y += verticalVelocity * deltaTime;

            bool groundedThisFrame = false;
            float targetGroundY = -999.0f;

            for (size_t i = 0; i < worldParts.size(); i++) {
                WorldPart& part = worldParts[i];
                
                float partMinX = part.position.x - part.size.x / 2.0f;
                float partMaxX = part.position.x + part.size.x / 2.0f;
                float partMinZ = part.position.z - part.size.z / 2.0f;
                float partMaxZ = part.position.z + part.size.z / 2.0f;
                float partTopY = part.position.y + part.size.y / 2.0f;
                float partBottomY = part.position.y - part.size.y / 2.0f;

                bool collisionX = (playerPos.x + 0.5f >= partMinX && playerPos.x - 0.5f <= partMaxX);
                bool collisionZ = (playerPos.z + 0.5f >= partMinZ && playerPos.z - 0.5f <= partMaxZ);

                if (collisionX && collisionZ) {
                    if (playerPos.y >= partBottomY && playerPos.y <= partTopY + 0.5f) {
                        if (verticalVelocity <= 2.0f && playerPos.y >= partTopY - 1.5f) {
                            if (partTopY > targetGroundY) {
                                targetGroundY = partTopY;
                                groundedThisFrame = true;
                            }
                        }
                    }
                }
            }

            if (groundedThisFrame) {
                playerPos.y = targetGroundY;
                verticalVelocity = 0.0f;
                isGrounded = true;
            } else {
                isGrounded = false;
            }

            if (playerPos.y < -50.0f) {
                playerPos = (Vector3){ 0.0f, 0.0f, 0.0f };
                verticalVelocity = 0.0f;
            }
        }

        {
            std::lock_guard<std::mutex> lock(dataMutex);
            for (auto& rp : remotePlayers) {
                rp.position = Vector3Lerp(rp.position, rp.targetPosition, 12.0f * deltaTime);
                rp.rotation += (rp.targetRotation - rp.rotation) * 12.0f * deltaTime;
            }
        }

        float pitchRad = DEG2RAD * cameraAnglePitch;
        float yawRad = DEG2RAD * cameraAngleYaw;

        camera.target = (Vector3){ playerPos.x, playerPos.y + 4.625f, playerPos.z };
        camera.position.x = camera.target.x + cameraDistance * cosf(pitchRad) * sinf(yawRad);
        camera.position.y = camera.target.y + cameraDistance * sinf(pitchRad);
        camera.position.z = camera.target.z + cameraDistance * cosf(pitchRad) * cosf(yawRad);

        BeginDrawing();
            ClearBackground((Color){ 140, 190, 245, 255 });

            BeginMode3D(camera);
                for (size_t i = 0; i < worldParts.size(); i++) {
                    WorldPart& p = worldParts[i];
                    DrawCube(p.position, p.size.x, p.size.y, p.size.z, p.color);
                    DrawCubeWires(p.position, p.size.x, p.size.y, p.size.z, DARKGRAY);

                    float topY = p.position.y + (p.size.y / 2.0f) + 0.002f;
					float bottomY = p.position.y - (p.size.y / 2.0f) - 0.002f;

if (topStudTex.id > 0) {
    rlDisableDepthTest();
    rlSetTexture(topStudTex.id);

    float x1 = -p.size.x / 2.0f;
    float x2 = p.size.x / 2.0f;
    float z1 = -p.size.z / 2.0f;
    float z2 = p.size.z / 2.0f;

    // حساب التكرار (UV) بناءً على حجم البلوك لتتوزع الستودز بشكل طبيعي مثل روبلوكس
    float uvScaleX = p.size.x / 2.0f;
	float uvScaleZ = p.size.z / 2.0f;

    rlBegin(RL_QUADS);
        rlColor4ub(255, 255, 255, 255);
        rlTexCoord2f(0.0f, 0.0f);           rlVertex3f(p.position.x + x1, topY, p.position.z + z1);
        rlTexCoord2f(0.0f, uvScaleZ);       rlVertex3f(p.position.x + x1, topY, p.position.z + z2);
        rlTexCoord2f(uvScaleX, uvScaleZ);   rlVertex3f(p.position.x + x2, topY, p.position.z + z2);
        rlTexCoord2f(uvScaleX, 0.0f);       rlVertex3f(p.position.x + x2, topY, p.position.z + z1);
    rlEnd();
    rlSetTexture(0);
    rlEnableDepthTest();
}

                    if (bottomSmsTex.id > 0) {
                        rlSetTexture(bottomSmsTex.id);
                        rlBegin(RL_QUADS);
                            rlColor4ub(255, 255, 255, 255);
                            rlTexCoord2f(0.0f, 0.0f);           rlVertex3f(p.position.x - p.size.x/2, bottomY,  p.position.z + p.size.z/2);
                            rlTexCoord2f(0.0f, p.size.x/2);     rlVertex3f(p.position.x - p.size.x/2, bottomY, p.position.z - p.size.z/2);
                            rlTexCoord2f(p.size.z/2, p.size.x/2); rlVertex3f(p.position.x + p.size.x/2, bottomY, p.position.z - p.size.z/2);
                            rlTexCoord2f(p.size.z/2, 0.0f);     rlVertex3f(p.position.x + p.size.x/2, bottomY,  p.position.z + p.size.z/2);
                        rlEnd();
                        rlSetTexture(0);
                    }
                }

                DrawR6Character(playerPos, playerRotation, faceTex, localUsername);

                {
                    std::lock_guard<std::mutex> lock(dataMutex);
                    for (size_t i = 0; i < remotePlayers.size(); i++) {
                        DrawR6Character(remotePlayers[i].position, remotePlayers[i].rotation, faceTex, remotePlayers[i].username);
                    }
                }
            EndMode3D();

            {
                std::vector<RemotePlayer> playersCopy;
                {
                    std::lock_guard<std::mutex> lock(dataMutex);
                    playersCopy = remotePlayers;
                }
                UpdateAndDrawBubbles(camera, deltaTime, playerPos, playersCopy);
            }

            DrawRectangleRec(menuBtnRect, CheckCollisionPointRec(mousePos, menuBtnRect) ? GRAY : Fade(BLACK, 0.5f));
            DrawRectangleRec(chatBtnRect, CheckCollisionPointRec(mousePos, chatBtnRect) ? GRAY : Fade(BLACK, 0.5f));

            if (menuBtnTex.id > 0) {
                DrawTexturePro(menuBtnTex, 
                    (Rectangle){ 0, 0, (float)menuBtnTex.width, (float)menuBtnTex.height },
                    (Rectangle){ menuBtnRect.x + 5, menuBtnRect.y + 5, menuBtnRect.width - 10, menuBtnRect.height - 10 },
                    (Vector2){ 0, 0 }, 0.0f, WHITE);
            }

            if (chatBtnTex.id > 0) {
                DrawTexturePro(chatBtnTex, 
                    (Rectangle){ 0, 0, (float)chatBtnTex.width, (float)chatBtnTex.height },
                    (Rectangle){ chatBtnRect.x + 5, chatBtnRect.y + 5, chatBtnRect.width - 10, chatBtnRect.height - 10 },
                    (Vector2){ 0, 0 }, 0.0f, WHITE);
            }

            DrawRectangleRec(chatBarRect, Fade(BLACK, 0.4f));
            if (isChatActive) {
                DrawRectangleLinesEx(chatBarRect, 2, YELLOW);
                DrawText(TextFormat("%s_", chatInput), 20, 68, 18, WHITE);
            } else {
                DrawText("Press '/' to Chat...", 20, 68, 18, LIGHTGRAY);
            }

            if (isMenuOpen) {
                DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.6f));
                DrawRectangleRec(menuOverlayRect, (Color){ 35, 35, 35, 240 });
                DrawRectangleLinesEx(menuOverlayRect, 2, DARKGRAY);

                DrawText(TextFormat("DeBlox Menu (Map %d)", currentMapId), (int)(menuOverlayRect.x + 35), (int)(menuOverlayRect.y + 15), 18, WHITE);

                bool hoverReset = CheckCollisionPointRec(mousePos, resetBtnRect);
                DrawRectangleRec(resetBtnRect, hoverReset ? LIGHTGRAY : GRAY);
                DrawText("Reset Character", (int)(resetBtnRect.x + 40), (int)(resetBtnRect.y + 10), 20, BLACK);

                bool hoverLeave = CheckCollisionPointRec(mousePos, leaveBtnRect);
                DrawRectangleRec(leaveBtnRect, hoverLeave ? RED : MAROON);
                DrawText("Leave Game", (int)(hoverLeave ? leaveBtnRect.x + 60 : leaveBtnRect.x + 60), (int)(leaveBtnRect.y + 10), 20, WHITE);
            }

            Texture2D activeCursor = cursorFarTex;
            if (CheckCollisionPointRec(mousePos, menuBtnRect) || CheckCollisionPointRec(mousePos, chatBtnRect) || (isMenuOpen && (CheckCollisionPointRec(mousePos, resetBtnRect) || CheckCollisionPointRec(mousePos, leaveBtnRect)))) {
                if (cursorArrowTex.id > 0) activeCursor = cursorArrowTex;
            } else if (CheckCollisionPointRec(mousePos, chatBarRect)) {
                if (cursorIBeamTex.id > 0) activeCursor = cursorIBeamTex;
            }

            if (activeCursor.id > 0) {
                DrawTexture(activeCursor, (int)mousePos.x, (int)mousePos.y, WHITE);
            } else {
                DrawCircleV(mousePos, 4, RED);
            }

        EndDrawing();
    }
// topY
    networkingActive = false;
    if (netThread.joinable()) netThread.join();

    RemovePlayerFromSupabase(localUsername);

    UnloadTexture(cursorFarTex);
    UnloadTexture(cursorArrowTex);
    UnloadTexture(cursorIBeamTex);
    UnloadTexture(topStudTex);
    UnloadTexture(bottomSmsTex);
    UnloadTexture(faceTex);
    UnloadTexture(menuBtnTex);
    UnloadTexture(chatBtnTex);

    CloseWindow();
    return 0;
}