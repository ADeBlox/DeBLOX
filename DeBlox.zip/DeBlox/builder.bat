@echo off
cd /d "C:\Users\saqht\OneDrive\Desktop\DeBlox"
set "PATH=C:\raylib\w64devkit\bin;%PATH%"

:: إغلاق اللعبة لو كانت شغالة بالخلفية عشان ما يصير تعارض
taskkill /f /im DeBLOX.exe >nul 2>&1

echo Loading
g++ app.cpp -o DeBLOX.exe -lraylib -lwininet -lopengl32 -lgdi32 -lwinmm

if %errorlevel% equ 0 (
    echo Good
    DeBLOX.exe %*
) else (
    echo ----------------------------------------
    echo [!] Error
    echo ----------------------------------------
    pause
)